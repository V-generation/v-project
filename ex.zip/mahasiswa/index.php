<?php 
	include 'inc/app.php';
	$data = new Mahasiswa();
	include '../temp/hd-mhs.php';
	// $data->session();
?>
   
<?php
//main page
$page = (isset($_GET['halaman']))?$_GET['halaman']:"dashboard";
switch($page) {
	case'dashboard':include"inc/dashboard.php";break;
	

	case 'dashboard':
	default:include"inc/dashboard.php";
	}
?>

<?php
	include '../temp/ft-mhs.php';
 ?>

