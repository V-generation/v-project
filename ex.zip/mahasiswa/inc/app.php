<?php 
	require_once('../app/db.php');
	/**
	 * 
	 */
	class Mahasiswa extends DB
	{
		
		function __construct()
		{
			# code...
		}
	}
 ?>