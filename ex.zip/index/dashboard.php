<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>.:: STIE PPI | Citra Raya ::.</title>
	<link rel="stylesheet" type="text/css" href="../inc/assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../inc/assets/css/animate.css">
	<link rel="stylesheet" type="text/css" href="../inc/assets/fa4/css/font-awesome.min.css">
	<script type="text/javascript" src="../inc/assets/js/jquery/jquery-3.2.1.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Roboto|Ubuntu+Condensed&display=swap" rel="stylesheet">
	<link rel="icon" type="icon" href="../im/att/logo.png">
	<style type="text/css" media="only screen and (min-width:992px)">
		body, html{
			height: 100%;
			font-family: 'Roboto', sans-serif;
			font-family: 'Ubuntu Condensed', sans-serif;
			/*overflow: hidden;*/
		}
		.bg{
			background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.9)),url('../img/att/bld.jpg');
			background-size: cover;
			height:100%;
			position: relative;
			background-attachment:cover;
			background-repeat: no-repeat; 
		}
		.text-hero{
			width:90%;
			color:white;
			position: relative;
			transform: translate(5%,30%);
			position: sticky;
			
		}
		.logo{
			/*float:left;*/
			margin-top:3%;
			width:15%;
		}
		.title{
			font-size: 200%;
			margin-top:-1%;
			float: left;
			/*display: none;*/
		}
		#registrasi{
			display: none;
			background: #ccc;
		    width: auto;
		    height: auto;
		    padding: 20px;
		    color: #333;
		    margin-top:5%;
		    border-radius:0.3em;
		}
		.list-group{
			background-color:transparent;
		}
		#contact{
			display: none;
		}
		#regis, #login{
			display:none;
		}
		#mid{
			width:500px;
			float:right;
			position: relative;
			transform: translate(0%, 0%);
			top:45%;
		}
		#market{
			position: relative;
			/*display: block;*/
			transform: translate(80%, -80%);
			top:0%;
		}
		.lc{
			text-align: left;
		}
		.blink{
			animation:blink 4000ms infinite;
		}
		@keyframes blink{
			from{opacity:0;color:gold;}
			to{opacity:1;color:red;}
		}
	</style>
	<!-- FOR MOBILE -->
	<style type="text/css" media="only screen and (max-width:600px)">
		body, html{
			height: 100%;
			font-family: 'Roboto', sans-serif;
			font-family: 'Ubuntu Condensed', sans-serif;
			/*overflow: hidden;*/
		}
		.bg{
			background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.9)),url('../img/att/bld.jpg');
			background-size: cover;
			height:100%;
			position: relative;
			background-attachment:cover;
			background-repeat: no-repeat; 
		}
		.text-hero{
			width:90%;
			position: relative;
			color:white;
			position: relative;
			transform: translate(5%,30%);
			position: sticky;
		}
		.title{
			font-size: 150%;
			margin-top:3%;
			text-align: center;
			/*float: left;*/
			/*display: none;*/
		}
		.md{
			font-size: 0.7em;
		}
		.sm{
			font-size: 0.5em;
		}
		.footer-hero{
			width:90%;
			background-color: #ECEBEB;
			transform:translate(4%,-1%);
			position: relative;
			bottom:0px;
			padding:0.3em;
			color:#9F9F9F;
			text-align: center;
			font-size: 0.8em;

		}
		.w-100{
			clear: both;
			margin-left: auto;
			margin-right: auto;
			width:50%;
		}
		.w-50{
			display: block;
			margin-left: auto;
			margin-right: auto;
			clear: both;
			width:25%;
		}
		#regis, #login{
			display: none;
		}
		#mid{
			width:250px;
			display: block;
			margin-left: auto;
			margin-right: auto;
			top:50%;
		}
		.blink{
			animation:blink 4000ms infinite;
		}
		@keyframes blink{
			from{opacity:0;color:gold;}
			to{opacity:1;color:red;}
		}
		.logo{
			/*float:left;*/
			margin-top:-20%;
			width:50%;
		}
		.lc{
			text-align:center;
		}
	</style>
</head>
<body>
	<div class="bg">
		<div class="text-hero">
			<div class="lc">
				<img src="../img/att/logo.png" class="animated bounceIn logo">
			</div>
			<div class="title">
				<p>
					STIE PPI <br>
					<small class="md">Sekolah Tinggi Ilmu Ekonomi Putra Perdana Indonesia</small> <br>
					<small class="sm">Terakreditasi BAN-PT <strong style="color:gold;" class="blink">B</strong></small>
				</p>
			</div>
			<div class="col-sm-4" id="mid">
				<div class="row">
					<div class="col-sm-6" onmouseover="showReg()" onmouseout="hideReg()">
						<button class="btn btn-block btn-primary btn-sm" id="reg"><i class="fa fa-user-plus"></i> Register</button>
							<!-- form Register -->
							<form class="form" id="regis">
								<div class="form-group">
									<input type="email" name="identity" class="form-control" placeholder="Your Email">
								</div>
								<div class="form-group">
									<input type="button" name="Reg" onclick="document.location='../form/regist';" class="btn btn-sm btn-primary" value="Register">
								</div>
							</form>
					</div>
					<div class="col-sm-6" onmouseover="show()" onmouseout="hide()">
						<button class="btn btn-block btn-primary btn-sm" id="log"><i class="fa fa-user"></i> Login
						</button>
							<!-- form login -->
							<form class="form" id="login">
								<div class="form-group">
									<input type="text" name="identity" class="form-control" placeholder="Your Account Code">
								</div>
								<div class="form-group">
									<input type="submit" name="login" class="btn btn-sm btn-primary" value="Login">
								</div>
							</form>
					</div>
				</div>
			</div>
		</div>
			<nav class="navbar fixed-bottom navbar-light bg-light">
				<p class="text-muted text-center">
					Jl. Raya Boulevard Citra Raya Mardi Grass Citra Raya
				</p>
				<p class="nav-link nav-right text-center">
					<i class="fa fa-phone"> 0813 1526 9591</i>
				</p>
			</nav>
	</div>
	<script type="text/javascript">
		function show(){
			document.getElementById('login').style.display="block";
			document.getElementById('login').style.opacity="1";
			document.getElementById('log').style.backgroundColor="#333";
		}
		function hide(){
			document.getElementById('login').style.display="none";
			document.getElementById('log').style.backgroundColor="";
		}
		function showReg(){
			document.getElementById('regis').style.display="block";
			document.getElementById('regis').style.opacity="1";
			document.getElementById('reg').style.backgroundColor="#333";
		}
		function hideReg(){
			document.getElementById('regis').style.display="none";
			document.getElementById('reg').style.backgroundColor="";
		}
	</script>
</body>
</html>