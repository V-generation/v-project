<?php 
	require_once('../app/controller.php'); 
	$data = new stiePortal();
	require_once('../temp/css.php'); 
?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>.:: Login System | PPI ::.</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="../inc/assets/css/login.css">
<link rel="stylesheet" href="../inc/assets/css/animate.css">

<style type="text/css">
	.sign-in-up .left-inner-addon {
    position: relative;
}

.sign-in-up .left-inner-addon input {
    padding-left: 30px;
}

.sign-in-up .left-inner-addon i {
    position: absolute;
    padding: 10px 12px;
    pointer-events: none;
}

.sign-in-up .right-inner-addon {
    position: relative;
}

.sign-in-up .right-inner-addon input {
    padding-right: 30px;
}

.sign-in-up .right-inner-addon i {
    position: absolute;
    right: 0px;
    padding: 17px 12px;
    pointer-events: none;
}

.sign-in-up .click2select {
    text-align: center;
    margin-top: 1em;
}

.sign-in-up .paywith {
    padding: 12px 12px 0 0;
    margin: 0;
    font-weight: bold;
}
.btn-danger, .btn-danger:hover{
  background-color: #333399 !important;
  border-color: #333399 !important;
}
.btn-primary, .btn-primary:hover{
  background-color: #3366CC !important;
  border-color: #3366CC !important;
}
input[type="text"], input[type="password"], .btn{
  border-radius: 0px;
}
.bac{
	background-image:linear-gradient(rgba(0,0,0,0.9),rgba(0,0,0,0.7)),url(../img/att/bld.jpg);
	background-size: cover;
	background-repeat: no-repeat;
	background-position: relative;
	position:relative;
	height: 100%;
}
.st{
	padding-top:5em;
	padding-bottom:5em;
}
.sts{
	background-color:#fefefe;
	padding:1em;
	border-radius:1em;
}
</style>
<div class="bac">
	<div class="container sign-in-up st">
  		<div class="row">
    		<div class="col-md-4 col-md-offset-4 animated bounceIn">
      		<br>
      		<!-- Nav tabs -->
		    	<div class="text-center">
		        	<div class="btn-group">
		          		<a href="#new" role="tab" data-toggle="tab" class="big btn btn-primary"><i class="fa fa-plus"></i> Create Account</a>
		          		<a href="#user" role="tab" data-toggle="tab" class="big btn btn-danger"><i class="fa fa-user"></i> Login</a>
		        	</div>
		      	</div>
      			<p class="click2select">Click to select</p>
  				<form class="form" method="POST">
	      			<div class="tab-content sts">
	      				<div class="tab-pane fade" id="user">
				          	<br>
	          				<fieldset>
					            <div class="form-group">
					              	<div class="right-inner-addon">
					                	<i class="fa fa-envelope"></i>
					                		<input class="form-control input-lg" placeholder="email address" type="text" name="email">
					              	</div>
					            </div>
					            <div class="form-group">
					              	<div class="right-inner-addon">
					                	<i class="fa fa-key"></i>
					                	<input class="form-control input-lg" placeholder="Password" type="password" name="password">
					              	</div>
					            </div>
	          				</fieldset>
	          				<br>
				          	<div class=" text-center">
				            	<input class="btn btn-primary btn-danger" type="submit" name="login" value="LOGIN">
				            		<?php 
				            			$data->login();
				            		 ?>
				          	</div>
        				</div>
          				</form>

			        <div class="tab-pane fade in active" id="new">
          				<br>
	          				<fieldset>
					           <?php echo "Anda tidak dapat membuat akun, silahkan jukan Akun dengan mengikuti tautan di bawah ini! <br> <a href='ticket'>Ajukan Akun</a>" ?>
					            </div>
	          				</fieldset>
	          				<hr>
					        </div>
		        	</div>

      			</div>
		    </div>
		</div>
	</div>
</div>

<!-- bootstrap 3.3.7 -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>