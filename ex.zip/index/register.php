<?php 
	require_once('../app/db.php');
	require_once('../app/index.db.php');
	$data = new Depan();

 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>.:: FORM REGISTRASI | STIE PPI ::.</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<!-- multistep form -->
</head>
<body>
	<form id="msform">
		<!-- progressbar -->
			<ul id="progressbar" class="text-center">
				<li class="active">KONTAK</li>
				<li>DATA PRIBADI</li>
				<li>DATA ORANG TUA</li>
				<li>DATA SEKOLAH</li>
				<li>DATA PRESTASI</li>
				<li>DATA STATUS</li>
				<li>KONFIRMASI</li>
			</ul>
		<!-- fieldsets -->
		<fieldset>
			<h2 class="fs-title">Kontak Anda</h2>
			<h3 class="fs-subtitle">Email & Handphone</h3>
			<input type="email" name="email" placeholder="Email" required="true"/>
			<input type="hp" name="hp" placeholder="HP" required="true"/>
			<input type="button" name="next" class="next action-button" value="Next" />
		</fieldset>
		<fieldset>
			<h2 class="fs-title">DATA PRIBADI</h2>
			<h3 class="fs-subtitle">Kemanan Data anda adalah asuransi kami!</h3>
			<input type="text" name="namalengkap" placeholder="Nama Lengkap" required/>
			<select name="gender" required>
				<option value="">- Jenis Kelamin-</option>
				<?php 
					if(is_array($data->getGender()) || is_object($data->getGender())){
						foreach($data->getGender() as $jk){
							echo "<option value='{$jk['id']}'>{$jk['gender']}</option>";
						}
					}
				?>
			</select>
			<input type="button" name="previous" class="previous action-button" value="Previous" />
			<input type="button" name="next" class="next action-button" value="Next" />
		</fieldset>
		<fieldset>
			<h2 class="fs-title">DATA ORANG TUA</h2>
			<h3 class="fs-subtitle">Kami tidak akan menjual data Anda!</h3>
			<input type="text" name="fname" placeholder="First Name" />
			<input type="text" name="lname" placeholder="Last Name" />
			<input type="text" name="phone" placeholder="Phone" />
			<textarea name="address" placeholder="Address"></textarea>
			<input type="button" name="previous" class="previous action-button" value="Previous" />
			<input type="button" name="next" class="next action-button" value="Next" />
		</fieldset>
		<fieldset>
			<h2 class="fs-title">DATA SEKOLAH</h2>
			<h3 class="fs-subtitle">Apalagi menyelundupkan data Anda!</h3>
			<input type="text" name="fname" placeholder="First Name" />
			<input type="text" name="lname" placeholder="Last Name" />
			<input type="text" name="phone" placeholder="Phone" />
			<textarea name="address" placeholder="Address"></textarea>
			<input type="button" name="previous" class="previous action-button" value="Previous" />
			<input type="button" name="next" class="next action-button" value="Next" />
		</fieldset>
		<fieldset>
			<h2 class="fs-title">DATA PRESTASI</h2>
			<h3 class="fs-subtitle">Apalagi menyelundupkan data Anda!</h3>
			<input type="text" name="fname" placeholder="First Name" />
			<input type="text" name="lname" placeholder="Last Name" />
			<input type="text" name="phone" placeholder="Phone" />
			<textarea name="address" placeholder="Address"></textarea>
			<input type="button" name="previous" class="previous action-button" value="Previous" />
			<input type="button" name="next" class="next action-button" value="Next" />
		</fieldset>
		<fieldset>
			<h2 class="fs-title">DATA STATUS</h2>
			<h3 class="fs-subtitle">Data Anda dipelihara dengan baik!</h3>
			<input type="text" name="fname" placeholder="First Name" />
			<input type="text" name="lname" placeholder="Last Name" />
			<input type="text" name="phone" placeholder="Phone" />
			<textarea name="address" placeholder="Address"></textarea>
			<input type="button" name="previous" class="previous action-button" value="Previous" />
			<input type="button" name="next" class="next action-button" value="Next" />
		</fieldset>
		<fieldset>
			<h2 class="fs-title">KONFIRMASI</h2>
			<h3 class="fs-subtitle">Terima Kasih Sudah menjadi bagian dari kami.</h3>
			<input type="text" name="fname" placeholder="First Name" />
			<input type="text" name="lname" placeholder="Last Name" />
			<input type="text" name="phone" placeholder="Phone" />
			<textarea name="address" placeholder="Address"></textarea>
			<input type="button" name="previous" class="previous action-button" value="Previous" />
			<input type="submit" name="submit" class="submit action-button" value="Submit" />
		</fieldset>
	</form>
<!-- jQuery -->
<script src="http://thecodeplayer.com/uploads/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<!-- jQuery easing plugin -->
<script src="http://thecodeplayer.com/uploads/js/jquery.easing.min.js" type="text/javascript"></script>
<script type="text/javascript" src="script.js"></script>

</body>
</html>