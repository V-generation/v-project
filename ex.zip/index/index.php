<?php 
	include '../app/controller.php';
	$data = new stiePortal();
?>
   
<?php
//main page
$page = (isset($_GET['halaman']))?$_GET['halaman']:"overview";
switch($page) {
	case'overview':include"dashboard.php";break;
	case'login':include"login.php";break;

	case 'overview':
	default:include"dashboard.php";
	}
?>

<?php
	// include '../temp/footer.php';
 ?>

