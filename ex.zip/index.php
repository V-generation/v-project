<html>
<head>
<meta http-equiv="refresh" content="0;url=index/index.php">
<title>.:: Kumpulan Script ::.</title>
<script language="javascript">
    window.location.href = "index/"
</script>
</head>
<body>
Go to <a href="index/index.php">Home</a>
</body>
</html>
