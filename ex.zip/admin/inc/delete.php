<?php 
	include 'app.php';
	include '../../temp/hd-admin.php';
	$data = new admin();
	$data->DeleteTa();
?>
