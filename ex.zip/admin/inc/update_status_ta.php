<?php 
	$data->switchTa();
 ?>