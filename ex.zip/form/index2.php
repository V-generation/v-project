
<!DOCTYPE html>
<html>
<head>
	<title>Pendaftaran Pesantren Tahfizh &amp; Ekonomi Islam Multazam - IDN</title>
	<meta name="description" content="Pembayaran Online Pesantren Tahfizh & Ekonomi Islam Multazam melalui Jaringan IDN. Bayar di Indmaret, I-Saku dan aplikasi online.">

	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta name = "format-detection" content = "telephone=no">

<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">

<script src="../temp/plugins/jquery/jquery.min.js"></script>
<link rel="stylesheet" href="../temp/plugins/uikit/css/uikit.min.css" />
<script src="../temp/plugins/uikit/js/uikit.min.js"></script>
<script src="../temp/plugins/uikit/js/uikit-icons.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Ubuntu+Condensed&display=swap" rel="stylesheet">


<meta name="twitter:card" value="Infra Digital Nusantara - Platform untuk Murid, Mahasiswa, dan Orang Tua untuk membayar keperluan sekolah dari aplikasi pembayaran favorit mereka.">


    <link rel="stylesheet" href="../temp/plugins/ifdn/ifdn_home.css">
    <link rel="stylesheet" href="../temp/plugins/ifdn/psb_styles.css">
    <script src="../temp/plugins/ifdn/firebase-app.js"></script>
    <script src="../temp/plugins/ifdn/firebase-firestore.js"></script>

    <style type="text/css">
        body { background: url("http://api.thumbr.it/whitenoise-361x370.png?background=f5f5f5ff&noise=9e9e9e&density=92&opacity=10"); min-height: 100vh; }
        /* overwrite check form*/

        .parsley-required, .parsley-type { position: absolute; top: 17px; right: 10px; pointer-events: none;}
        section { background-color: transparent;}
        .bg-gradient {
            background: rgb(255,255,255);
            background: linear-gradient(180deg, rgba(255,255,255,1) 0%, rgba(201,255,248,1) 45%, rgba(255,251,235,1) 70%, rgba(255,255,255,1) 100%);
        }

        @media screen and (min-width: 768px) {
            .bg-gradient {
                background: transparent;
            }
        }
    </style>
</head>
<body>
    <div id="loading">
        <div id="loading-center">
            <div id="loading-center-absolute">
                <img src="../temp/plugins/ifdn/preloader.svg">
            </div>
        </div>
    </div>
	<section class="clearspace">
		<div class="content">
            <div id="register-intro" class="register-intro-full">
                <div class="section-intro">
                    <div class="section1">
                        <div class="banner_photo">
                            <img id="photo_desktop" class="for-desktop" src="">
                            <img id="photo_mobile" class="for-mobile" src="">
                        </div>
                        <div class="logo">
                            <img id="psb-logo-intro" src="" onError="this.onerror=null;this.src='../img/att/logo.png';" width="100">
                        </div>
                        <div class="ppdb-title">
                            <h2>PMB</h2>
                            <div class="school-name">STIE PPI<br class="for-desktop">Putra Perdana Indonesia<br class="for-desktop">Citra Raya</div>
                            <div class="school-years">Tahun Akademik 2020-2021</div>
                            <div class="school-expired">
                                Tes Gelombang I : 5 April 2020 pukul 09:00 - 11:30  <br>
                                Tes Gelombang II : 12 April 2020 pukul 09:00 - 11:30
                            </div>
                        </div>
                    </div>
                    <div class="section2">
                        <div class="section-holder">
                            <div class="bg-gradient uk-text-center">
                                <img src="" class="img-hero">
                            </div>
                            <div class="step">
                                <div class="step-item">
                                    <div class="step-image">
                                        <img src="../temp/plugins/ifdn/icon_form.svg">
                                    </div
                                    ><div class="step-desc">
                                        <h2 id="txt-intro-01"></h2>
                                        <span id="txt-intro-desc01"></span>
                                    </div>
                                </div>
                                <div class="step-item">
                                    <div class="step-image">
                                        <img src="../temp/plugins/ifdn/icon_attachment.svg">
                                    </div
                                    ><div class="step-desc">
                                        <h2 id="txt-intro-02"></h2>
                                        <span id="txt-intro-desc02"></span>
                                    </div>
                                </div>
                                <div class="step-item">
                                    <div class="step-image">
                                        <img src="../temp/plugins/ifdn/icon_time.svg">
                                    </div
                                    ><div class="step-desc">
                                        <h2 id="txt-intro-03"></h2>
                                        <span id="txt-intro-desc03"></span>
                                    </div>
                                </div>
                                <div class="intro-action for-mobile">
                                    <button type="button" class="intro btn-default btn-full btn-action">SAYA MENGERTI, LANJUT DAFTAR</button><br><br>
                                </div>
                                <div class="intro-action for-desktop">
                                    <button type="button" class="intro btn-default btn-fix btn-action">SAYA MENGERTI, LANJUT DAFTAR</button><br><br>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="register-footer">
                        <div id="footer-school-name"></div>
                        <div id="footer-school-address"></div><br class="for-mobile">
                        <div class="contact-info"></div>
                    </div>
                </div>
            </div>
            <div id="register" style="display:none;">
                <div class="reg-header">
                    <img id="psb-logo-page" src="" onError="this.onerror=null;this.src='http://www.infradigital.io/img/icon_billers.png';">
                    <h2>Pendaftaran untuk<br><span id="psb-school-name"></span></h2>
                </div>
                <form action="" method="post" class="uk-form-stacked register-intro-full" id="reg-form">
                    <input type="hidden" name="internal_biller_name" value="Pesantren Tahfizh Ekonomi Islam Multazam" />
                    <input type="hidden" name="internal_biller_address" value="Jl. Kp. Parigi, RT.04/RW.06, Sukamulya, Kec. Rumpin, Bogor, Jawa Barat 16350" />
                    <input type="hidden" name="internal_biller_phone" value="0896-3078-7772" />
                    <input type="hidden" name="internal_biller_email" value="info@infradigital.io" />
                    <input type="hidden" name="internal_bill_key_label" value="Nomor Registrasi" />
                    <input type="hidden" name="internal_account_code" value="BRI SYARIAH" />
                    <input type="hidden" name="internal_bill_component_expires" value="7" />
                    <input type="hidden" name="internal_bill_component_names" value="Uang Formulir Pendaftaran" />
                    <input type="hidden" name="internal_bill_component_amounts" value="250000" />
                        <div class="uk-text-center" style="padding: 50px 0; display: none" id="loading">
                            <img src="../temp/plugins/ifdn/preloader-form.gif" width="30"><br><br>
                            Harap tunggu<br>data Anda sedang diproses
                        </div>
                        <div class="reg-form">
                            <div class="form-active for-desktop">
                                <div class="paging-holder">
                                    <ul>
                                        <li><div>1</div><br><span>Calon Siswa</span></li>
                                        <li><div>2</div><br><span>Orang Tua / Wali</span></li>
                                        <li><div>3</div><br><span>Data Rincian</span></li>
                                        <li><div>4</div><br><span>Registrasi</span></li>
                                        <li><div>5</div><br><span>Upload</span></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="form-active-mobile for-mobile">
                                <ul>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                </ul>
                            </div>
                            <!-- FORM ====================================================== -->
                            <!-- STUDENT -->
                            <div id="section1" class="form-section">
                                <h2 class="form-title">Data Calon Santri</h2>
                                <div class="form-content">
                                    <!-- <h3>Data Pribadi</h3>-->
                                    <div class="uk-margin-small" id="wrp_student_schoollevel">
                                        <label class="uk-form-label">Jenjang Pendidikan</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-select" id="dapodik_0129_student_schoollevel" name="dapodik_0129_student_schoollevel">
                                                <option value="MI">MI</option>
                                                <option value="MTS">MTS</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small" id="wrp_student_name">
                                        <label class="uk-form-label">Nama Lengkap</label>
                                        <div class="uk-form-controls">
                                            <input class="uk-input" type="text" name="dapodik_0101_student_name" maxlength="30" required >
                                        </div>
                                    </div>
                                    <div class="uk-margin-small" id="wrp_student_gender">
                                        <label class="uk-form-label">Jenis Kelamin</label>
                                        <div class="uk-form-controls option-spacer">
                                            <input class="uk-radio" type="radio" id="student_gender_male" name="dapodik_0102_student_gender" value="male" checked="checked"> Pria &nbsp;&nbsp;&nbsp;
                                            <input class="uk-radio" type="radio" id="student_gender_female" name="dapodik_0102_student_gender" value="female"> Wanita
                                        </div>
                                    </div>
                                    <input type="hidden" id="student_gender_hidden" name="dapodik_0102_student_gender" value="female">
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_cellphone">
                                                <label class="uk-form-label">Nomor Ponsel Orang Tua &nbsp;&nbsp;<span uk-icon="icon: info; ratio: .8" uk-tooltip="Nomor ponsel diperlukan juga untuk mengakses aplikasi Jaringan IDN"></span></label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="number" name="dapodik_0103_student_cellphone" id="student_cellphone" maxlength="16" onkeypress="limit(this.id, event)" required >
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small" id="wrp_student_email">
                                                <label class="uk-form-label">Email Orang Tua</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="email" name="dapodik_0104_student_email" required >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_nisn">
                                                <label class="uk-form-label">NISN</label>
                                                <div class="uk-form-controls">
                                                    <!-- <span class="optional">Tidak wajib diisi</span>-->
                                                    <input class="uk-input" type="number" name="dapodik_0105_student_nisn" id="student_nisn" maxlength="16" onkeypress="limit(this.id, event)">
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small" id="wrp_student_nik">
                                                <label class="uk-form-label">NIK / No KITAS (untuk WNA)</label>
                                                    <div class="uk-form-controls">
                                                        <!-- <span class="optional">Tidak wajib diisi</span>-->
                                                        <input class="uk-input" type="number" name="dapodik_0106_student_nik" id="student_nik" maxlength="16" onkeypress="limit(this.id, event)" required>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_birth_place">
                                                <label class="uk-form-label">Tempat Lahir</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="text" name="dapodik_0107_student_birth_place" maxlength="20" required >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_birth_date">
                                                <label class="uk-form-label">Tanggal Lahir</label>
                                                <div class="uk-form-controls">
                                                    <span class="uk-form-icon" uk-icon="icon: calendar; ratio: .8"></span>
                                                    <input class="uk-input" type="date" id="student_date_birth" name="dapodik_0108_student_birth_date" required="" max="2018-12-12" min="1970-01-01" >
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small" id="wrp_student_akte">
                                                <label class="uk-form-label">No Registrasi Akta Lahir</label>
                                                <div class="uk-form-controls">
                                                    <!-- <span class="optional">Tidak wajib diisi</span>-->
                                                    <input class="uk-input" type="text" name="dapodik_0109_student_akte" maxlength="16" >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small" id="wrp_student_address">
                                        <label class="uk-form-label">Alamat Lengkap</label>
                                        <div class="uk-form-controls">
                                            <textarea class="uk-textarea" rows="5" name="dapodik_0115_student_address" required></textarea>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small" id="wrp_student_transport">
                                        <label class="uk-form-label">Moda Transportasi</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-select" name="dapodik_0116_student_transport">
                                                <option value="">- Pilih -</option>
                                                <option value="Jalan Kaki">Jalan Kaki</option>
                                                <option value="Kendaraan Pribadi">Kendaraan Pribadi</option>
                                                <option value="Kendaraan Umum">Kendaraan Umum</option>
                                                <option value="Jemputan Sekolah">Jemputan Sekolah</option>
                                                <option value="Kereta Api">Kereta Api</option>
                                                <option value="Andong/Bendi/Sado/Dokar/Delman/Becak">Andong/Bendi/Sado/Dokar/Delman/Becak</option>
                                                <option value="Perahu penyebrangan/Rakit/Getek">Perahu penyebrangan/Rakit/Getek</option>
                                                <option value="Lainnya">Lainnya</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_religion">
                                                <label class="uk-form-label">Agama</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0110_student_religion" required>
                                                        <option value="">- Pilih -</option>
                                                        <option value="Islam">Islam</option>
                                                        <option value="Khatolik">Khatolik</option>
                                                        <option value="Kristen / Protestan">Kristen/Protestan</option>
                                                        <option value="Hindu">Hindu</option>
                                                        <option value="Budha">Budha</option>
                                                        <option value="Khong Hu Chu">Khong Hu Chu</option>
                                                        <option value="Kepercayaan Kpd Tuan YME">Kepercayaan Kpd Tuan YME</option>
                                                        <option value="Lainnya">Lainnya</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_pray">
                                                <label class="uk-form-label">Kebiasaan Sholat</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="custom_0901_kebiasaan_sholat" >
                                                        <option value="">- Pilih -</option>
                                                        <option value="Setiap hari">Setiap Hari</option>
                                                        <option value="Jarang-jarang">Jarang-jarang</option>
                                                        <option value="Pernah">Pernah</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small" id="wrp_student_pray">
                                                <label class="uk-form-label">Kebiasaan Baca Al-Quran</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="custom_0902_kebiasaan_baca_alquran" >
                                                        <option value="">- Pilih -</option>
                                                        <option value="Setiap hari">Setiap Hari</option>
                                                        <option value="Jarang-jarang">Jarang-jarang</option>
                                                        <option value="Pernah">Pernah</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small" id="wrp_student_nationality">
                                        <label class="uk-form-label">Kewarganegaraan</label>
                                        <div class="uk-form-controls option-spacer">
                                            <input class="uk-radio" type="radio" name="dapodik_0111_student_nationality" value="WNI" checked="checked"> Indonesia (WNI) &nbsp;&nbsp;&nbsp;
                                            <input class="uk-radio" type="radio" name="dapodik_0111_student_nationality" value="WNA"> Asing (WNA)<br>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small" id="wrp_student_country">
                                        <label class="uk-form-label">Negara Asal (Jika WNA)</label>
                                        <div class="uk-form-controls">
                                            <input class="uk-input" type="text" name="dapodik_0112_student_country" id="student_country" >
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_abk">
                                                <label class="uk-form-label">Berkebutuhan Khusus</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0113_student_abk">
                                                        <option value="">- Pilih -</option>
                                                        <option value="Tidak">Tidak</option>
                                                        <option value="Netra (A)">Netra (A)</option>
                                                        <option value="Rungu (B)">Rungu (B)</option>
                                                        <option value="Grahita ringan (C)">Grahita ringan (C)</option>
                                                        <option value="Grahita Sedang (C1)">Grahita Sedang (C1)</option>
                                                        <option value="Daksa Ringan (D)">Daksa Ringan (D)</option>
                                                        <option value="Daksa Sedang (D1)">Daksa Sedang (D1)</option>
                                                        <option value="Laras (E)">Laras (E)</option>
                                                        <option value="Wicara (F)">Wicara (F)</option>
                                                        <option value="Tuna ganda (G)">Tuna ganda (G)</option>
                                                        <option value="Hiper aktif (H)">Hiper aktif (H)</option>
                                                        <option value="Cerdas Istimewa (i)">Cerdas Istimewa (i)</option>
                                                        <option value="Bakat Istimewa (J)">Bakat Istimewa (J)</option>
                                                        <option value="Kesulitan Belajra (K)">Kesulitan Belajra (K)</option>
                                                        <option value="Narkoba (N)">Narkoba (N)</option>
                                                        <option value="Indigo (O)">Indigo (O)</option>
                                                        <option value="Down Sindrome (P)">Down Sindrome (P)</option>
                                                        <option value="Autis (Q)">Autis (Q)</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_bloodtype">
                                                <label class="uk-form-label">Golongan Darah</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0114_student_bloodtype" >
                                                        <option value="">- Pilih -</option>
                                                        <option value="O">O</option>
                                                        <option value="A">A</option>
                                                        <option value="B">B</option>
                                                        <option value="AB">AB</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small" id="wrp_student_name">
                                                <label class="uk-form-label">Riwayat Penyakit</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="text" name="custom_0903_riwayat_penyakit" maxlength="20">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <h3>Lainnya</h3> -->
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small" id="wrp_student_reference">
                                                <label class="uk-form-label">Referensi</label>
                                                <div class="uk-form-controls">
                                                    <!-- <span class="optional">Tidak wajib diisi</span> -->
                                                    <input class="uk-input" type="text" name="dapodik_0127_student_reference" placeholder="" >
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small" id="wrp_student_extracurricular">
                                                <label class="uk-form-label">Jenis Ekstrakurikuler</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0128_student_extracurricular">
                                                        <option value="">- Pilih -</option>
                                                        <option value="Bahasa">Bahasa</option>
                                                        <option value="Karya Ilmiah Remaja/Sains KIR">Karya Ilmiah Remaja/Sains KIR</option>
                                                        <option value="Kerohanian">Kerohanian</option>
                                                        <option value="Komputer dan Teknologi">Komputer dan Teknologi</option>
                                                        <option value="Olahaga/Beladiri">Olahaga/Beladiri</option>
                                                        <option value="Otomotif/Bengkel/Bikers">Otomotif/Bengkel/Bikers</option>
                                                        <option value="Palang Merah Remaja (PMR)">Palang Merah Remaja (PMR)</option>
                                                        <option value="Paskibra">Paskibra</option>
                                                        <option value="Palang Keamanan Sekolah (PKS)">Palang Keamanan Sekolah (PKS)</option>
                                                        <option value="Pencinta Alam">Pencinta Alam</option>
                                                        <option value="Pramuka">Pramuka</option>
                                                        <option value="Seni Media">Seni Media</option>
                                                        <option value="Seni Musik">Seni Musik</option>
                                                        <option value="Seni Tari dan Peran">Seni Tari dan Peran</option>
                                                        <option value="Unit Kesehatan Sekolah(UKS)">Unit Kesehatan Sekolah(UKS)</option>
                                                        <option value="Wirausaha/Koperasi/keterampilan produktif">Wirausaha/Koperasi/keterampilan produktif</option>
                                                        <option value="Lainnya">Lainnya</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- PARENT -->
                            <div id="section2" class="form-section">
                                <h2 class="form-title">Ayah</h2>
                                <div id="parent-01" class="form-content">
                                    <!-- <h3>Ayah</h3> -->
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Nama Ayah Kandung</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="text" name="dapodik_0201_father_name" maxlength="30" required >
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Tahun Lahir Ayah</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="number" name="dapodik_0204_father_yearbirth" id="father_yearbirth" maxlength="4" onkeypress="limit(this.id, event)" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">NIK Ayah</label>
                                                <div class="uk-form-controls">
                                                    <!-- <span class="optional">Tidak wajib diisi</span>-->
                                                    <input class="uk-input" type="number" name="dapodik_0202_father_nik" id="father_nik" maxlength="16" onkeypress="limit(this.id, event)" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">No Kartu Keluarga</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="number" name="dapodik_0203_father_kk" id="father_kk" maxlength="16" onkeypress="limit(this.id, event)" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Pendidikan Ayah</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0205_father_education" required>
                                                        <option value="">- Pilih -</option>
                                                        <option value="Tidak Sekolah">Tidak Sekolah</option>
                                                        <option value="Putus SD">Putus SD</option>
                                                        <option value="SD Sederajat">SD Sederajat</option>
                                                        <option value="SMP Sederajat">SMP Sederajat</option>
                                                        <option value="SMA Sederajat">SMA Sederajat</option>
                                                        <option value="D1">D1</option>
                                                        <option value="D2">D2</option>
                                                        <option value="D3">D3</option>
                                                        <option value="D4/S1">D4/S1</option>
                                                        <option value="S2">S2</option>
                                                        <option value="S3">S3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Pekerjaan Ayah</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0206_father_job" required>
                                                        <option value="">- Pilih -</option>
                                                        <option value="Tidak Bekerja">Tidak Bekerja</option>
                                                        <option value="Nelayan">Nelayan</option>
                                                        <option value="Petani">Petani</option>
                                                        <option value="Peternak">Peternak</option>
                                                        <option value="PNS/TNI/POLRI">PNS/TNI/POLRI</option>
                                                        <option value="Karyawan Swasta">Karyawan Swasta</option>
                                                        <option value="Pedagang Kecil">Pedagang Kecil</option>
                                                        <option value="Pedagang Besar">Pedagang Besar</option>
                                                        <option value="Wiraswasta">Wiraswasta</option>
                                                        <option value="Wirausaha">Wirausaha</option>
                                                        <option value="Buruh">Buruh</option>
                                                        <option value="Pensiunan">Pensiunan</option>
                                                        <option value="Meninggal Dunia">Meninggal Dunia</option>
                                                        <option value="Lain-lain">Lain-lain</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Penghasilan Bulanan Ayah</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0207_father_salary" required>
                                                        <option value="">- Pilih -</option>
                                                        <option value="Kurang dari 500,000">Kurang dari 500,000</option>
                                                        <option value="500.000 - 999.9999">500.000 - 999.9999</option>
                                                        <option value="1 juta - 1.999.999">1 juta - 1.999.999</option>
                                                        <option value="2 juta - 4.999.999">2 juta - 4.999.999</option>
                                                        <option value="5 juta - 20 juta">5 juta - 20 juta</option>
                                                        <option value="Lebih dari 20 juta ">Lebih dari 20 juta</option>
                                                        <option value="Tidak Berpenghasilan">Tidak Berpenghasilan</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small">
                                        <label class="uk-form-label">Berkebutuhan Khusus</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-select" name="dapodik_0208_father_special">
                                                <option value="">- Pilih -</option>
                                                <option value="Tidak">Tidak</option>
                                                <option value="Netra (A)">Netra (A)</option>
                                                <option value="Rungu (B)">Rungu (B)</option>
                                                <option value="Grahita ringan (C)">Grahita ringan (C)</option>
                                                <option value="Grahita Sedang (C1)">Grahita Sedang (C1)</option>
                                                <option value="Daksa Ringan (D)">Daksa Ringan (D)</option>
                                                <option value="Daksa Sedang (D1)">Daksa Sedang (D1)</option>
                                                <option value="Laras (E)">Laras (E)</option>
                                                <option value="Wicara (F)">Wicara (F)</option>
                                                <option value="Tuna ganda (G)">Tuna ganda (G)</option>
                                                <option value="Hiper aktif (H)">Hiper aktif (H)</option>
                                                <option value="Cerdas Istimewa (i)">Cerdas Istimewa (i)</option>
                                                <option value="Bakat Istimewa (J)">Bakat Istimewa (J)</option>
                                                <option value="Kesulitan Belajra (K)">Kesulitan Belajra (K)</option>
                                                <option value="Narkoba (N)">Narkoba (N)</option>
                                                <option value="Indigo (O)">Indigo (O)</option>
                                                <option value="Down Sindrome (P)">Down Sindrome (P)</option>
                                                <option value="Autis (Q)">Autis (Q)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <h2 class="form-title">Ibu</h2>
                                <div id="parent-02" class="form-content" style="padding-bottom: 0px;">
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Nama Ibu Kandung</label>
                                                    <div class="uk-form-controls">
                                                        <input class="uk-input" type="text" name="dapodik_0301_mother_name" maxlength="30" required >
                                                    </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Tahun Lahir Ibu</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="number" name="dapodik_0303_mother_yearbirth" id="mother_yearbirth" maxlength="4" onkeypress="limit(this.id, event)" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small">
                                        <label class="uk-form-label">NIK Ibu</label>
                                        <div class="uk-form-controls">
                                            <!-- <span class="optional">Tidak wajib diisi</span>-->
                                            <input class="uk-input" type="number" name="dapodik_0302_mother_nik" id="mother_nik" maxlength="16" onkeypress="limit(this.id, event)" required>
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Pendidikan Ibu</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0304_mother_education" required>
                                                        <option value="">- Pilih -</option>
                                                        <option value="Tidak Sekolah">Tidak Sekolah</option>
                                                        <option value="Putus SD">Putus SD</option>
                                                        <option value="SD Sederajat">SD Sederajat</option>
                                                        <option value="SMP Sederajat">SMP Sederajat</option>
                                                        <option value="SMA Sederajat">SMA Sederajat</option>
                                                        <option value="D1">D1</option>
                                                        <option value="D2">D2</option>
                                                        <option value="D3">D3</option>
                                                        <option value="D4/S1">D4/S1</option>
                                                        <option value="S2">S2</option>
                                                        <option value="S3">S3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Pekerjaan Ibu</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0305_mother_job" required>
                                                        <option value="">- Pilih -</option>
                                                        <option value="Tidak Bekerja">Tidak Bekerja</option>
                                                        <option value="Nelayan">Nelayan</option>
                                                        <option value="Petani">Petani</option>
                                                        <option value="Peternak">Peternak</option>
                                                        <option value="PNS/TNI/POLRI">PNS/TNI/POLRI</option>
                                                        <option value="Karyawan Swasta">Karyawan Swasta</option>
                                                        <option value="Pedagang Kecil">Pedagang Kecil</option>
                                                        <option value="Pedagang Besar">Pedagang Besar</option>
                                                        <option value="Wiraswasta">Wiraswasta</option>
                                                        <option value="Wirausaha">Wirausaha</option>
                                                        <option value="Buruh">Buruh</option>
                                                        <option value="Pensiunan">Pensiunan</option>
                                                        <option value="Meninggal Dunia">Meninggal Dunia</option>
                                                        <option value="Lain-lain">Lain-lain</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Penghasilan Bulanan Ibu</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0306_mother_salary" required>
                                                        <option value="">- Pilih -</option>
                                                        <option value="Kurang dari 500,000">Kurang dari 500,000</option>
                                                        <option value="500.000 - 999.9999">500.000 - 999.9999</option>
                                                        <option value="1 juta - 1.999.999">1 juta - 1.999.999</option>
                                                        <option value="2 juta - 4.999.999">2 juta - 4.999.999</option>
                                                        <option value="5 juta - 20 juta">5 juta - 20 juta</option>
                                                        <option value="Lebih dari 20 juta ">Lebih dari 20 juta</option>
                                                        <option value="Tidak Berpenghasilan">Tidak Berpenghasilan</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small">
                                        <label class="uk-form-label">Berkebutuhan Khusus</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-select" name="dapodik_0307_mother_special">
                                                <option value="">- Pilih -</option>
                                                <option value="Tidak">Tidak</option>
                                                <option value="Netra (A)">Netra (A)</option>
                                                <option value="Rungu (B)">Rungu (B)</option>
                                                <option value="Grahita ringan (C)">Grahita ringan (C)</option>
                                                <option value="Grahita Sedang (C1)">Grahita Sedang (C1)</option>
                                                <option value="Daksa Ringan (D)">Daksa Ringan (D)</option>
                                                <option value="Daksa Sedang (D1)">Daksa Sedang (D1)</option>
                                                <option value="Laras (E)">Laras (E)</option>
                                                <option value="Wicara (F)">Wicara (F)</option>
                                                <option value="Tuna ganda (G)">Tuna ganda (G)</option>
                                                <option value="Hiper aktif (H)">Hiper aktif (H)</option>
                                                <option value="Cerdas Istimewa (i)">Cerdas Istimewa (i)</option>
                                                <option value="Bakat Istimewa (J)">Bakat Istimewa (J)</option>
                                                <option value="Kesulitan Belajra (K)">Kesulitan Belajra (K)</option>
                                                <option value="Narkoba (N)">Narkoba (N)</option>
                                                <option value="Indigo (O)">Indigo (O)</option>
                                                <option value="Down Sindrome (P)">Down Sindrome (P)</option>
                                                <option value="Autis (Q)">Autis (Q)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-text-right">
                                    <a class="btn-link uk-text-small" id="btn-add-wali" style="padding-bottom: 80px; display: inline-block; padding-right: 20px;" ><span uk-icon="icon: plus-circle"></span> Tambah Wali Siswa</a>
                                </div>
                                <div id="parent-03" class="form-content" style="display: none;">
                                    <h2 class="form-title" style="position: relative;">Wali <button type="button" class="uk-position-small uk-position-top-right" id="btn-remove-wali" style="top: 6px" uk-close></button></h2><br>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">]
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Nama Wali</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="text" name="dapodik_0401_surrogate_name" >
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Tahun Lahir Wali</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="number" name="dapodik_0403_surrogate_yearbirth" id="surrogate_yearbirth" maxlength="4" onkeypress="limit(this.id, event)">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small">
                                        <label class="uk-form-label">NIK Wali</label>
                                        <div class="uk-form-controls">
                                            <!-- <span class="optional">Tidak wajib diisi</span>-->
                                            <input class="uk-input" type="number" name="dapodik_0402_surrogate_nik" id="surrogate_nik" maxlength="16" onkeypress="limit(this.id, event)">
                                        </div>
                                    </div>
                                    <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Pendidikan Wali</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0404_surrogate_education">
                                                        <option value="">- Pilih -</option>
                                                        <option value="Tidak Sekolah">Tidak Sekolah</option>
                                                        <option value="Putus SD">Putus SD</option>
                                                        <option value="SD Sederajat">SD Sederajat</option>
                                                        <option value="SMP Sederajat">SMP Sederajat</option>
                                                        <option value="SMA Sederajat">SMA Sederajat</option>
                                                        <option value="D1">D1</option>
                                                        <option value="D2">D2</option>
                                                        <option value="D3">D3</option>
                                                        <option value="D4/S1">D4/S1</option>
                                                        <option value="S2">S2</option>
                                                        <option value="S3">S3</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="colspacer">
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Pekerjaan Wali</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0405_surrogate_job">
                                                        <option value="">- Pilih -</option>
                                                        <option value="Tidak Bekerja">Tidak Bekerja</option>
                                                        <option value="Nelayan">Nelayan</option>
                                                        <option value="Petani">Petani</option>
                                                        <option value="Peternak">Peternak</option>
                                                        <option value="PNS/TNI/POLRI">PNS/TNI/POLRI</option>
                                                        <option value="Karyawan Swasta">Karyawan Swasta</option>
                                                        <option value="Pedagang Kecil">Pedagang Kecil</option>
                                                        <option value="Pedagang Besar">Pedagang Besar</option>
                                                        <option value="Wiraswasta">Wiraswasta</option>
                                                        <option value="Wirausaha">Wirausaha</option>
                                                        <option value="Buruh">Buruh</option>
                                                        <option value="Pensiunan">Pensiunan</option>
                                                        <option value="Meninggal Dunia">Meninggal Dunia</option>
                                                        <option value="Lain-lain">Lain-lain</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-margin-small">
                                                <label class="uk-form-label">Penghasilan Bulanan Wali</label>
                                                <div class="uk-form-controls">
                                                    <select class="uk-select" name="dapodik_0406_surrogate_salary">
                                                        <option value="">- Pilih -</option>
                                                        <option value="Kurang dari 500,000">Kurang dari 500,000</option>
                                                        <option value="500.000 - 999.9999">500.000 - 999.9999</option>
                                                        <option value="1 juta - 1.999.999">1 juta - 1.999.999</option>
                                                        <option value="2 juta - 4.999.999">2 juta - 4.999.999</option>
                                                        <option value="5 juta - 20 juta">5 juta - 20 juta</option>
                                                        <option value="Lebih dari 20 juta ">Lebih dari 20 juta</option>
                                                        <option value="Tidak Berpenghasilan">Tidak Berpenghasilan</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="uk-margin-small">
                                        <label class="uk-form-label">Berkebutuhan Khusus</label>
                                        <div class="uk-form-controls">
                                            <select class="uk-select" name="dapodik_0407_surrogate_special">
                                                <option value="">- Pilih -</option>
                                                <option value="Tidak">Tidak</option>
                                                <option value="Netra (A)">Netra (A)</option>
                                                <option value="Rungu (B)">Rungu (B)</option>
                                                <option value="Grahita ringan (C)">Grahita ringan (C)</option>
                                                <option value="Grahita Sedang (C1)">Grahita Sedang (C1)</option>
                                                <option value="Daksa Ringan (D)">Daksa Ringan (D)</option>
                                                <option value="Daksa Sedang (D1)">Daksa Sedang (D1)</option>
                                                <option value="Laras (E)">Laras (E)</option>
                                                <option value="Wicara (F)">Wicara (F)</option>
                                                <option value="Tuna ganda (G)">Tuna ganda (G)</option>
                                                <option value="Hiper aktif (H)">Hiper aktif (H)</option>
                                                <option value="Cerdas Istimewa (i)">Cerdas Istimewa (i)</option>
                                                <option value="Bakat Istimewa (J)">Bakat Istimewa (J)</option>
                                                <option value="Kesulitan Belajra (K)">Kesulitan Belajra (K)</option>
                                                <option value="Narkoba (N)">Narkoba (N)</option>
                                                <option value="Indigo (O)">Indigo (O)</option>
                                                <option value="Down Sindrome (P)">Down Sindrome (P)</option>
                                                <option value="Autis (Q)">Autis (Q)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <!-- DATA PRIODIK -->
                        <div id="section3" class="form-section">
                            <h2 class="form-title uk-text-left">Data Priodik</h2>
                            <div class="form-content" style="padding-bottom: 10px;">
                                <!-- <h3>Data Priodik</h3> -->
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Tinggi Badan (cm)</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0501_student_height" id="student_height" maxlength="3" onkeypress="limit(this.id, event)" >
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Berat Badan (kg)</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0502_student_weight" id="student_weight" maxlength="3" onkeypress="limit(this.id, event)" >
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Jarak Tempat Tinggal ke Sekolah</label>
                                            <div class="uk-form-controls option-spacer">
                                                <input class="uk-radio" type="radio" name="dapodik_0503_student_distance" value="< 1 KM" checked="checked"> < 1 KM &nbsp;&nbsp;&nbsp;
                                                <input class="uk-radio" type="radio" name="dapodik_0503_student_distance" value="> 1 KM"> > 1 KM
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Waktu Tempuh ke Sekolah</label>
                                            <div class="uk-form-controls">
                                                <span class="optional">contoh: 1 jam 20 menit</span>
                                                <input class="uk-input" type="text" name="dapodik_0504_student_travelhour" id="student_travelhour" maxlength="20">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h2 class="form-title uk-text-left">Prestasi</h2>
                            <div class="form-content" style="padding-bottom: 10px;">
                                <!-- <h3>Prestasi</h3> -->
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Jenis Prestasi</label>
                                            <div class="uk-form-controls">
                                                <select class="uk-select" name="dapodik_0601_student_achievement_01">
                                                    <option value="">- Pilih -</option>
                                                    <option value="Sains">Sains</option>
                                                    <option value="Seni">Seni</option>
                                                    <option value="Olah Raga">Olah Raga</option>
                                                    <option value="Lain-lain">Lain-lain</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Nama Prestasi</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="text" name="dapodik_0602_student_achievement_name_01" >
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Tingkat</label>
                                            <div class="uk-form-controls">
                                                <select class="uk-select" name="dapodik_0603_student_achievement_level_01">
                                                    <option value="">- Pilih -</option>
                                                    <option value="Sekolah">Sekolah</option>
                                                    <option value="Kecamatan">Kecamatan</option>
                                                    <option value="Kabupaten">Kabupaten</option>
                                                    <option value="Provinsi">Provinsi</option>
                                                    <option value="Nasional">Nasional</option>
                                                    <option value="International">International</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Tahun</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0604_student_achievement_year_01" id="dapodik_0604_student_achievement_year_01" maxlength="4" onkeypress="limit(this.id, event)">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Penyelenggara</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="text" name="dapodik_0605_student_achievement_organizer_01" >
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h2 class="form-title uk-text-left">Beasiswa</h2>
                            <div class="form-content" style="padding-bottom: 10px;">
                                <!-- <h3>Beasiswa</h3> -->
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Jenis Beasiswa</label>
                                            <div class="uk-form-controls">
                                                <select class="uk-select" name="dapodik_0701_student_scholarship_01">
                                                    <option value="">- Pilih -</option>
                                                    <option value="Anak berprestasi">Anak berprestasi</option>
                                                    <option value="Anak Miskin">Anak Miskin</option>
                                                    <option value="Pendidikan">Pendidikan</option>
                                                    <option value="Unggulan">Unggulan</option>
                                                    <option value="Lain-lain">Lain-lain</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Tahun Mulai</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0703_student_scholarship_start_01" id="dapodik_0703_student_scholarship_start_01" maxlength="4" onkeypress="limit(this.id, event)">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Tahun Selesai</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0704_student_scholarship_end_01" id="dapodik_0704_student_scholarship_end_01" maxlength="4" onkeypress="limit(this.id, event)">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-margin-small">
                                    <label class="uk-form-label">Keterangan</label>
                                    <div class="uk-form-controls">
                                        <input class="uk-input" type="text" name="dapodik_0702_student_scholarship_description_01" >
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- DATA REGISTRASI-->
                        <div id="section4" class="form-section">
                            <h2 class="form-title uk-text-left">Registrasi Peserta Didik</h2>
                            <div class="form-content" style="padding-bottom: 10px;">
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Jenis Pendaftaran</label>
                                            <div class="uk-form-controls">
                                                <select class="uk-select" name="dapodik_0802_registration_type">
                                                    <option value="Siswa Baru">Siswa Baru</option>
                                                    <option value="Pindahan">Pindahan</option>
                                                    <option value="Kembali Bersekolah">Kembali Bersekolah</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Jenjang</label>
                                            <div class="uk-form-controls">
                                                <select class="uk-select" name="dapodik_0806_registration_level">
                                                    <option value="MI">MI</option>
                                                    <option value="MTS">MTS</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Asal Sekolah</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="text" name="dapodik_0803_registration_schoolorigin" id="registration_schoolorigin" maxlength="30">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Tahun Lulus</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0805_registration_schoolenddate" id="registration_schoolenddate" maxlength="4" onkeypress="limit(this.id, event)">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-margin-small">
                                    <label class="uk-form-label">Alamat Sekolah</label>
                                    <div class="uk-form-controls">
                                        <textarea class="uk-textarea" rows="5" name="dapodik_0804_registration_schooladdress" maxlength="100"></textarea>
                                    </div>
                                </div>
                                <div class="uk-grid-collapse uk-child-width-expand@s" uk-grid>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Nomor Peserta Ujian</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0807_registration_number" id="registration_number" maxlength="20" onkeypress="limit(this.id, event)">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="colspacer">
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Nomor Seri Ijazah</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0808_registration_certificate" id="registration_certificate" maxlength="16" onkeypress="limit(this.id, event)">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="uk-margin-small">
                                            <label class="uk-form-label">Nomor Seri SKHUN</label>
                                            <div class="uk-form-controls">
                                                <input class="uk-input" type="number" name="dapodik_0809_registration_skhus" id="registration_skhus" maxlength="16" onkeypress="limit(this.id, event)">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-text-right">
                                    <a class="btn-link uk-text-small" id="btn-add-study" style="padding: 0 40px 40px 0px; display: inline-block;" ><span uk-icon="icon: plus-circle"></span> Tambah Data Nilai</a>
                                </div>
                                <div id="form-study">
                                    <div class="study-list">
                                        <strong><span class="for-mobile">NILAI</span><span class="for-desktop">DATA NILAI MATA PELAJARAN</span></strong><br><br>
                                        <a class="uk-link uk-position-small uk-position-top-right uk-text-small" id="btn-add-study-item" style="top: 5px;"><span uk-icon="icon: plus-circle"></span> Tambah Data Nilai</a>
                                        <div id="matpel_1" class="uk-grid-collapse" uk-grid> 
                                            <div class="uk-width-expand@m colspacer" style="position: relative;">
                                                <label class="uk-form-label">Mata Pelajaran</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="text" name="dapodik_0810_matpel_1">
                                                </div>
                                            </div>
                                            <div class="uk-width-1-3@s" style="position: relative;">
                                                <label class="uk-form-label">Nilai</label>
                                                <div class="uk-form-controls">
                                                    <input class="uk-input" type="number" name="dapodik_0810_nilai_1" maxlength="3" onkeypress="limit(this.id, event)">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- UPLOAD DOC -->
                        <div id="section5" class="form-section">
                            <h2 class="form-title uk-text-left">Upload</h2>
                            <div class="form-content">
                                <div id="doc-list" class="uk-grid-collapse uk-child-width-expand@s uk-text-center" uk-grid>
                                    <div id="" class="uk-width-1-2@s ">
                                        <div class="uk-placeholder uk-text-center">
                                            <div uk-form-custom>
                                                <input id="img-additional-1" type="file" name="file_foto_2x3" >
                                                <div class="uk-link"><span uk-icon="file-text"></span><br><span class="img-additional-1-text">Foto 2x3</span></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="" class="uk-width-1-2@s ">
                                        <div class="uk-placeholder uk-text-center">
                                            <div uk-form-custom>
                                                <input id="img-additional-2" type="file" name="file_foto_3x4" >
                                                <div class="uk-link"><span uk-icon="file-text"></span><br><span class="img-additional-2-text">Foto 3x4</span></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="" class="uk-width-1-2@s ">
                                        <div class="uk-placeholder uk-text-center">
                                            <div uk-form-custom>
                                                <input id="img-additional-3" type="file" name="file_surat_sehat_dokter" >
                                                <div class="uk-link"><span uk-icon="file-text"></span><br><span class="img-additional-3-text">Surat Keterangan Sehat Dokter</span></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="" class="uk-width-1-2@s ">
                                        <div class="uk-placeholder uk-text-center">
                                            <div uk-form-custom>
                                                <input id="img-additional-4" type="file" name="file_skkb" >
                                                <div class="uk-link"><span uk-icon="file-text"></span><br><span class="img-additional-4-text">Surat Keterangan Kelakuan Baik</span></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="" class="uk-width-1-2@s ">
                                        <div class="uk-placeholder uk-text-center">
                                            <div uk-form-custom>
                                                <input id="img-additional-5" type="file" name="file_surat_keterangan_pindah" >
                                                <div class="uk-link"><span uk-icon="file-text"></span><br><span class="img-additional-5-text">Surat Keterangan Pindah</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>
                            </div>
                        </div>
                        <!-- FORM NAVIGATION -->
                        <div class="form-navigation">
                            <!-- <button type="button" class="previous btn-default btn-fix btn-cancel"><span uk-icon="icon: arrow-left"></span> Kembali</button>-->
                            <button type="button" class="previous btn-default btn-fix btn-cancel uk-position-left"><span uk-icon="icon: arrow-left"></span> Kembali</button>
                            <button type="button" class="next btn-default btn-fix btn-action">Lanjut</button>
                            <input type="button" class="btn-default btn-fix btn-action" id="btn-daftar" value="Daftar">
                        </div>
                    </div>
				</form>
            </div>
	 	</div>
	</section>
    <div id="age-mi" class="uk-flex-top" uk-modal>
        <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title">Usia Siswa Belum Cukup/Lebih</h2>
            <p>Untuk mendaftar Madrasah Ibtidaiyah di Pesantren TEI Multazam, siswa harus berumur minimal 7th atau maksimal 8th pada saat ajaran baru dimulai yaitu tanggal 1 Juli 2020.</p>
        </div>
    </div>
    <div id="age-mts" class="uk-flex-top" uk-modal>
        <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical">
            <button class="uk-modal-close-default" type="button" uk-close></button>
            <h2 class="uk-modal-title">Usia Siswa Belum Cukup/Lebih</h2>
            <p>Untuk mendaftar Madrasah Tsanawiyah di Pesantren TEI Multazam, siswa harus sudah berumur minimal 12th atau maksimal 15th pada saat ajaran baru dimulai yaitu tanggal 1 Juli 2020.</p>
        </div>
    </div>
	<script type="text/javascript" src="../temp/plugins/ifdn/main.js"></script>
	<script type="text/javascript" src="../temp/plugins/ifdn/parsley.js"></script>
    <script type="text/javascript" src="../temp/plugins/ifdn/psmb.js"></script>
    <script type="text/javascript">
        // GET STATIC DATA
        getPSB("psb", "10139", "#loading");

        $('#student_gender_male').prop("checked", false);
        $('#student_gender_female').prop("checked", true);
        $("input:radio[name=dapodik_0102_student_gender]").attr('disabled', true);

        $('#dapodik_0129_student_schoollevel').on('change', function() {
            switch($(this).val()) {
            case "MI":
                $('#student_gender_male').prop("checked", false);
                $('#student_gender_female').prop("checked", true);
                $("input:radio[name=dapodik_0102_student_gender]").attr('disabled', true);
                $("#student_gender_hidden").attr('disabled', false);
                
                console.log("mi");
                break;
            case "MTS":
                $('#student_gender_male').prop("checked", true);
                $('#student_gender_female').prop("checked", false);
                $("input:radio[name=dapodik_0102_student_gender]").attr('disabled', false);
                $("#student_gender_hidden").attr('disabled', true);
               
                console.log("mts");
                break;
            default:
                // code block
            }
        });

        // CHECK LIMITATION
        function checkAgeLimitation(option, id){
            var ageIsValid = false;
            var modal = "";
            switch($("#" + option).val()) {
            case "MI":
                if(getAge($("#" + id).val()) < 7 || getAge($("#" + id).val()) > 8){
                    modal = UIkit.modal('#age-mi');
                }else{
                    ageIsValid = true;
                }
                break;
            case "MTS":
                if(getAge($("#" + id).val()) < 11 || getAge($("#" + id).val()) > 15){
                    modal = UIkit.modal('#age-mts');
                }else{
                    ageIsValid = true;
                }
                break;
            default:
                // code block
            }

            if(!ageIsValid){
                modal.toggle();
                $("#" + id).val("");
                $(".uk-modal-close-default").click(function(){
                    $("#" + id).focus();
                });
            }

            return ageIsValid;
        }



        //SUBMIT FORM
        $("#btn-daftar").click(function(){
            $(".reg-form").hide();
            $("#loading").show();

            var formData = $('#reg-form').serialize();

            var formJson = {};
            $("#reg-form").serializeArray().map(function(x){formJson[x.name] = x.value;});

            // SUBMIT ALL FORM
            $.ajax({
                type: "POST",
                url: '/psb/10139/submit',
                data: formJson,
                success: function(data, textStatus) {
                    $('input[type="file"]').each(function(index, value) {
                        var id = $(this).attr('id');
                        var imgType = $(this).attr('name');
                        var files = document.getElementById(id).files;
                        if (files.length > 0) {
                            var content = files[0];
                            var uploadData = new FormData();
                            uploadData.append('img_content', content);
                            var xhr = new XMLHttpRequest();
                            xhr.onload = function() {
                                if (xhr.status != 200) { // analyze HTTP status of the response
                                console.log('Error ' + xhr.status + ':' + xhr.statusText); // e.g. 404: Not Found
                                }
                            };
                            xhr.open('POST', '/psb/upload/' + data.billId + '/' + imgType, false);
                            xhr.send(uploadData);
                        }
                    });

                    $("#loading").hide();
                    window.location.href = '/psb/app?biller_code=10139&bill_key=' + data.billKey + "&message=" + data.message;
            },
                error: function(xhr, textStatus, errorThrown) {
                    $("#loading").hide();
                    alert(textStatus + ':' + errorThrown);
            }
            });
        });
	</script>
</body>
</html>
