<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../temp/plugins/uikit/css/uikit.min.css"/>
        <link href="css/styles.css" rel="stylesheet">
    </head>
    <body>
        

        <script src="../temp/plugins/uikit/uikit.min.js" 
                integrity="sha256-v789mr/zBbgR53mfydCI78CSAF+9+nRqu+JRfs1UPg0=" crossorigin="anonymous"></script>
        <script src="../temp/plugins/uikit/js/uikit-icons.min.js" 
                integrity="sha256-l+AmZGiFz41J+gms80qC7faslJDberZDhjEsmDmQy8s=" crossorigin="anonymous"></script>
    </body>
</html>